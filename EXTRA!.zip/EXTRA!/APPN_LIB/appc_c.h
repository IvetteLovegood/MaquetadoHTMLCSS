
/* Copyright (c) 1995, Attachmate Corporation.  All rights reserved.         */

/*****************************************************************************/
/* This include file is for backward compatibility, real file is winappc.h   */
/*****************************************************************************/
#include <winappc.h>

