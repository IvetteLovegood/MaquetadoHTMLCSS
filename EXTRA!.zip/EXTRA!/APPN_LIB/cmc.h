
/* Copyright (c) 1995, Attachmate Corporation.  All rights reserved.         */

/*****************************************************************************/
/* This include file is for backward compatibility, real file is wincpic.h   */
/*****************************************************************************/
#include <wincpic.h>

