
/* Copyright (c) 1995, Attachmate Corporation.  All rights reserved.         */

/*****************************************************************************/
/* This include file is for backward compatibility, real file is wincsv.h    */
/*****************************************************************************/
#include <wincsv.h>

